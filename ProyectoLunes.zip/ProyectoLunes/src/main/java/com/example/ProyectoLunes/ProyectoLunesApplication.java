package com.example.ProyectoLunes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoLunesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoLunesApplication.class, args);
	}

}
