package com.example.ProyectoLunes;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoLunesApplicationTests {

	@Test
	void contextLoads() {
	}

}
